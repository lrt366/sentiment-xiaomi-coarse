import datetime
# import logging
from .classifiers import SVMClassifier
from .feature_extraction import ChiSquare
from .tools import get_accuracy
from .tools import Write2File
import pickle

class Test:
    def __init__(self, type_, train_num, test_num, feature_num, max_iter, C, k, corpus, ORNOT):
        self.type = type_
        self.train_num = train_num
        self.test_num = test_num
        self.feature_num = feature_num
        self.max_iter = max_iter
        self.C = C
        self.k = k
        self.parameters = [train_num, test_num, feature_num]

        # self.logger = logging.getLogger('sentiment')

        # get the corpus
        # self.train_data, self.train_labels = corpus.get_train_corpus(train_num)
        # self.test_data, self.test_labels = corpus.get_test_corpus(test_num)
        #
        # # feature extraction
        if ORNOT == False:
            fe = ChiSquare(self.train_data, self.train_labels)
            self.best_words = fe.best_words(feature_num)
            a = open("word_best", 'wb')
            pickle.dump(self.best_words, a)
            a.close()  # 完成存储
        else:
            f = open("F:/lrt233/lrt233/sentiment/word_best", 'rb')
            self.best_words =  pickle.load(f)
            f.close()

        # self.single_classifiers_got = False
        #
        # self.precisions = [[0, 0],  # bayes
        #                    [0, 0],  # maxent
        #                    [0, 0]]  # svm


    # def set_precisions(self, precisions):
    #     self.precisions = precisions
    #
    # import pandas as pd
    # from sklearn import svm
    # from sklearn.model_selection import GridSearchCV
    #
    #
    #
    # def test_bayes(self):
    #
    #     self.logger.info('BayesClassifier')
    #     self.logger.info('Train set = {}; Test set = {}'.format(self.train_num, self.test_num))
    #
    #     from .classifiers import BayesClassifier
    #     bayes = BayesClassifier(self.train_data, self.train_labels, self.best_words)
    #
    #     classify_labels = []
    #     self.logger.info("BayesClassifier is testing ...")
    #     for data in self.test_data:
    #         classify_labels.append(bayes.classify(data))
    #     self.logger.info("BayesClassifier tests over.")
    #
    #     filepath = "runout/Bayes-%s-train-%d-test-%d-f-%d-%s.xls" % \
    #                (self.type,
    #                 self.train_num, self.test_num, self.feature_num,
    #                 datetime.datetime.now().strftime(
    #                     "%Y-%m-%d-%H-%M-%S"))
    #
    #     self.write(filepath, classify_labels, 0)
    #
    def write(self, filepath, classify_labels, i=-1):
        results = get_accuracy(self.test_labels, classify_labels, self.parameters)
        # if i >= 0:
        #     self.precisions[i][0] = results[10][1] / 100
        #     self.precisions[i][1] = results[7][1] / 100

        # Write2File.write_contents(filepath, results)




    def test_svm(self, ORNOT, str):

        # self.logger.info('SVMClassifier')
        # self.logger.info('Train set = {}; Test set = {}; C = {}'.format(self.train_num, self.test_num, self.C))


        svm = SVMClassifier( self.best_words, self.C, ORNOT)
        # svm.train(self.train_data, self.train_labels)
        result = svm.test_one(str)
        return result



        classify_labels = []
        # self.logger.info("SVMClassifier is testing ...")
        for data in self.test_data:
            classify_labels.append(svm.classify(data))
        # self.logger.info("SVMClassifier tests over.")

        filepath = "runout/SVM-%s-train-%d-test-%d-f-%d-C-%d-%s-lin.xls" % \
                   (self.type,
                    self.train_num, self.test_num,
                    self.feature_num, self.C,
                    datetime.datetime.now().strftime(
                        "%Y-%m-%d-%H-%M-%S"))

        self.write(filepath, classify_labels, 2)


def test_phone(str):
    from .corpus import PhoneCorpus
    ORNOT = True  #是否储存了模型
    type_ = "phone"
    train_num = 10000
    test_num = 500
    feature_num = 10500
    max_iter = 1500
    C = 70
    # k = 13
    k = [1, 3, 5, 7, 9, 11, 13]
    # corpus = PhoneCorpus()
    corpus = 1

    test = Test(type_, train_num, test_num, feature_num, max_iter, C, k, corpus, ORNOT)

    # test.test_bayes()
    resurt = test.test_svm(ORNOT, str)
    return resurt


# def test_dict():
#     """
#     test the classifier based on Sentiment Dict
#     """
#     print("DictClassifier")
#     print("---" * 45)
#
#     from .classifiers import DictClassifier
#
#     ds = DictClassifier()
#
#     # 对一个单句进行情感分析
#     # a_sentence = "剁椒鸡蛋好咸,土豆丝很好吃"    # result值: 修改前(1)/修改后(1)
#     # a_sentence = "要是米饭再多点儿就好了"    # result值: 修改前(1)/修改后(0)
#     a_sentence = "要是米饭再多点儿就更好了"    # result值: 修改前(0)/修改后(0)
#     # a_sentence = "不太好吃，相当难吃，要是米饭再多点儿就好了"    # result值: 修改前(1)/修改后(0)
#     result = ds.analyse_sentence(a_sentence)
#     print(result)

    # 对一个文件内语料进行情感分析
    # corpus_filepath = "D:/My Data/NLP/SA/waimai/positive_corpus_v1.txt"
    # runout_filepath_ = "f_runout/f_dict-positive_test.txt"
    # pos_results = ds.analysis_file(corpus_filepath, runout_filepath_, start=3000, end=4000-1)
    #
    # corpus_filepath = "D:/My Data/NLP/SA/waimai/negative_corpus_v1.txt"
    # runout_filepath_ = "f_runout/f_dict-negative_test.txt"
    # neg_results = ds.analysis_file(corpus_filepath, runout_filepath_, start=3000, end=4000-1)
    #
    # origin_labels = [1] * 1000 + [0] * 1000
    # classify_labels = pos_results + neg_results
    #
    # print(len(classify_labels))
    #
    # filepath = "f_runout/Dict-waimai-%s.xls" % (
    #     datetime.datetime.now().strftime("%Y-%m-%d-%H-%M-%S"))
    # results = get_accuracy(origin_labels, classify_labels, [1000, 1000, 0])
    #
    # Write2File.write_contents(filepath, results)
